//
//  main.m
//  TimeClock
//
//  Created by 周泽文 on 16/7/25.
//  Copyright © 2016年 zhouzewen. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
